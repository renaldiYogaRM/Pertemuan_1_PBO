import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Latar here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Latar extends World
{

    /**
     * Constructor for objects of class Latar.
     * 
     */
    public Latar()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(600, 400, 1); 

        prepare();
    }
    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        Plane plane = new Plane();
        addObject(plane,159,122);
        plane.setRotation(90);
        Plane plane2 = new Plane();
        addObject(plane2,249,256);
        Plane plane3 = new Plane();
        addObject(plane3,356,142);
        plane3.setLocation(354,134);
        plane3.setRotation(-90);
        Plane plane4 = new Plane();
        addObject(plane4,429,303);
        plane4.setRotation(-180);
    }
}
