import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Plane here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Plane extends Actor
{
    /**
     * Act - do whatever the Plane wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    private int speed = 10;
    public void act()
    {
        move(speed);
        World w = getWorld();
        if (isTouching(Plane.class))
        {
            setImage("bomb.png");
            speed = 0;
        }
        if (isAtEdge())
        {
            setRotation(getRotation()-90);
            turn(17);
        }
    }
    public Plane()
    {
        GreenfootImage img = this.getImage();
        img.scale(40,40);
        this.setImage(img);
    }   
}
